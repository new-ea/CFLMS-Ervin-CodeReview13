<?php

namespace App\Controller;

use App\Entity\Events;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

// CLASSES FOR THE FORM
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventsController extends AbstractController
{
    /**
    * @Route("/", name="home_page")
    */
   public function index()
   {
        $events = $this->getDoctrine()
                       ->getRepository(Events::class)
                       ->findAll();
        return $this->render('render/index.html.twig', array("events"=>$events));
   }

    /**
    * @Route("/details/{id}", name="details_page")
    */
    public function details($id)
    {
        $event = $this->getDoctrine()
                      ->getRepository(Events::class)
                      ->find($id);
        return $this->render('render/details.html.twig', array("event"=>$event));
    }

    /**
    * @Route("/create", name="create_page")
    */
   public function create(Request $request)
   {
        $event = new Events;

        $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('date', DateType::class, array('attr' => array('style'=>'margin-bottom:15px')))
                                                ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('capacity', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px'))) 
                                                ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('phone', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px'))) 
                                                ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('zip', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px'))) 
                                                ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('link', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('type', ChoiceType::class, array('choices'=>array('Concert'=>'Concert', 'Musical'=>'Musical', 'Theater'=>'Theater', 'Festival'=>'Festival'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
                                                ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-secondary', 'style'=>'margin-bottom:15px; margin-top:15px; width:200px')))
        ->getForm();
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $description = $form['description']->getData();
            $image = $form['image']->getData();
            $capacity = $form['capacity']->getData();
            $email = $form['email']->getData();
            $phone = $form['phone']->getData();
            $address = $form['address']->getData();
            $zip = $form['zip']->getData();
            $city = $form['city']->getData();
            $link = $form['link']->getData();
            $type = $form['type']->getData();

            $event->setName($name);
            $event->setDate($date);
            $event->setDescription($description);
            $event->setImage($image);
            $event->setCapacity($capacity);
            $event->setEmail($email);
            $event->setPhone($phone);
            $event->setAddress($address);
            $event->setZip($zip);
            $event->setCity($city);
            $event->setLink($link);
            $event->setType($type);

            $em = $this->getDoctrine()->getManager();
            $em->persist($event);
            $em->flush();
            $this->addFlash(
                'notice',
                'Event Added'
            );
            return $this->redirectToRoute('home_page');
        }
        return $this->render('render/create.html.twig', array('form' => $form->createView()));
   }

    /**
    * @Route("/edit/{id}", name="edit_page")
    */
   public function edit($id, Request $request)
   {
        $event = $this->getDoctrine()
                      ->getRepository(Events::class)
                      ->find($id);

        $event->setName($event->getName());    
        $event->setDate($event->getDate()); 
        $event->setDescription($event->getDescription());  
        $event->setImage($event->getImage());   
        $event->setCapacity($event->getCapacity());
        $event->setEmail($event->getEmail());
        $event->setPhone($event->getPhone());
        $event->setAddress($event->getAddress());
        $event->setZip($event->getZip());
        $event->setCity($event->getCity());
        $event->setLink($event->getLink());
        $event->setType($event->getType());

        $form = $this->createFormBuilder($event)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('date', DateType::class, array('attr' => array('style'=>'margin-bottom:15px')))
                                                ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('capacity', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px'))) 
                                                ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('phone', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px'))) 
                                                ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('zip', NumberType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px'))) 
                                                ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('link', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                                                ->add('type', ChoiceType::class, array('choices'=>array('Concert'=>'Concert', 'Musical'=>'Musical', 'Theater'=>'Theater', 'Festival'=>'Festival'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
                                                ->add('save', SubmitType::class, array('label'=> 'Edit Event', 'attr' => array('class'=> 'btn btn-secondary', 'style'=>'margin-bottom:15px; margin-top:15px; width:200px')))
        ->getForm();
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $description = $form['description']->getData();
            $image = $form['image']->getData();
            $capacity = $form['capacity']->getData();
            $email = $form['email']->getData();
            $phone = $form['phone']->getData();
            $address = $form['address']->getData();
            $zip = $form['zip']->getData();
            $city = $form['city']->getData();
            $link = $form['link']->getData();
            $type = $form['type']->getData();

            $em = $this->getDoctrine()->getManager();
            $event = $em->getRepository(Events::class)->find($id);

            $event->setName($name);
            $event->setDate($date);
            $event->setDescription($description);
            $event->setImage($image);
            $event->setCapacity($capacity);
            $event->setEmail($email);
            $event->setPhone($phone);
            $event->setAddress($address);
            $event->setZip($zip);
            $event->setCity($city);
            $event->setLink($link);
            $event->setType($type);

            $em->flush();
            $this->addFlash(
                   'notice',
                   'Todo Updated'
            );

            return $this->redirectToRoute('home_page');
        }
        return $this->render('render/edit.html.twig', array('form' => $form->createView()));

   }
    /**
    * @Route("/delete/{id}", name="delete_page")
    */
    public function delete($id, Request $request){
            $em = $this->getDoctrine()->getManager();
            $event = $em->getRepository(Events::class)->find($id);
            $em->remove($event);
            $em->flush();
            $this->addFlash(
                    'notice',
                    'Event Removed'
            );

            return $this->redirectToRoute('home_page');
    }

    /**
    * @Route("/filter/{type}", name="filter_page")
    */
    public function filter($type, Request $request){
            // $repository = $this->getDoctrine()->getRepository(Events::class);
            // $event = $repository->findByType($type);
            // return $this->render('render/filter.html.twig', array("event"=>$event));

            $events = $this->getDoctrine()
                          ->getRepository(Events::class)
                          ->findByType($type);
            return $this->render('render/filter.html.twig', array("events"=>$events));
    }
}
